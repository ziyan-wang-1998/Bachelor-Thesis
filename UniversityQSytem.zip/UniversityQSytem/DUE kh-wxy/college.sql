/*
SQLyog Ultimate v12.08 (64 bit)
MySQL - 8.0.15 : Database - college
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`college` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */;

USE `college`;

/*Table structure for table `college_book` */

DROP TABLE IF EXISTS `college_book`;

CREATE TABLE `college_book` (
  `name` varchar(300) DEFAULT NULL,
  `position` varchar(300) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `college_book` */

insert  into `college_book`(`name`,`position`) values ('Prince','It is at 3rd floor on the 25th bookshelf'),('prince','It is at 3rd floor on the 25th bookshelf'),('youandme','It is at 11rd floor on the 3th bookshelf'),('anapple','It is at 1th floor!'),('anApple','It is at 1th floor!');

/*Table structure for table `college_canteen` */

DROP TABLE IF EXISTS `college_canteen`;

CREATE TABLE `college_canteen` (
  `name` varchar(500) DEFAULT NULL,
  `content` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `college_canteen` */

insert  into `college_canteen`(`name`,`content`) values ('The first Canteen','hamburger,Vegetables'),('2nd Canteen','toamto,potato'),('3rd canteen','French fries'),('4th canteen','potato,Chinese food'),('5th canteen','Fish');

/*Table structure for table `college_history` */

DROP TABLE IF EXISTS `college_history`;

CREATE TABLE `college_history` (
  `history` varchar(5000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `college_history` */

insert  into `college_history`(`history`) values ('    The University of Roland was founded in 1635. It was originally founded by Cardinal Pazmani Peter in Najisomt (now in Tinawa, Slovakia) as a Catholic university teaching theology and philosophy. From 1770 to 1780, she moved to Budapest and was transformed into the Royal University of Hungary with the support of the Austrian Queen and Hungarian Queen Maria Theresa. In order to meet the needs of social development, universities continue to establish many new departments in the next few decades. In the second half of the 19th century, Loran University developed into the core of modern higher education. At that time, setting up majors covered almost all disciplines. In 1950, the University was reorganized and officially renamed the University of Uterforsh Rowland. It was named after the world famous physicist, Uterforsh Rowland. The name is still in use today.\n\n\n\nNowadays, the new campus has been built along the picturesque Danube River, offering a variety of disciplines such as natural sciences, Social Sciences and informatics.');

/*Table structure for table `college_login` */

DROP TABLE IF EXISTS `college_login`;

CREATE TABLE `college_login` (
  `id` varchar(20) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `college_login` */

insert  into `college_login`(`id`,`password`) values ('test','123'),('Test','123'),('123','123');

/*Table structure for table `college_news` */

DROP TABLE IF EXISTS `college_news`;

CREATE TABLE `college_news` (
  `news_title` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `news_content` varchar(5000) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `college_news` */

insert  into `college_news`(`news_title`,`news_content`) values ('2 children dead, many homes damaged as storms pummel South','DALLAS — Powerful storms that rolled across the South on Saturday spawned at least two suspected tornadoes, damaged homes and killed two children in Texas, authorities said.'),('Previously deported parents hope to resume asylum claims and reunite with children','Seventeen parents who were separated from their children by immigration authorities were released from a detention center near Calexico this week, more than a month after they returned to the Mexico border to claim asylum in the United States.'),('Hurricane Maria dealt woman\'s life mission a major setback -- but she isn\'t giving up','UTUADO, PUERTO RICO- After 50 years of inter-agency efforts dedicated to the recovery of the Puerto Rican Parrot, the most devastating natural phenomenon in Puerto Rico\'s modern history -- Hurricane María -- endangered the existence of the endemic bird.'),('Beagles force-fed pesticides, now released and up for adoption','Thirty-two beagles that were saved from an animal testing lab where they were force-fed pesticides are now ready for new homes -- and will likely have no trouble being adopted.'),('Super Moon!','Super Moon is here.............');

/*Table structure for table `college_position` */

DROP TABLE IF EXISTS `college_position`;

CREATE TABLE `college_position` (
  `position` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `college_position` */

insert  into `college_position`(`position`) values ('You are at 3rd floor! Machine ID is 005!');

/*Table structure for table `college_society` */

DROP TABLE IF EXISTS `college_society`;

CREATE TABLE `college_society` (
  `title` varchar(500) DEFAULT NULL,
  `activity` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `college_society` */

insert  into `college_society`(`title`,`activity`) values ('Club activities:Basketball','Time:5.12.2019  Place: Prince Hall'),('Club activities:Badminton','Time:5.12.2019  Place: Prince Hall'),('Club activities:Swimming','Time:5.12.2019  Place: Prince Hall'),('Club activities:Movie','Time:5.12.2019  Place: Prince Hall'),('Club activities:Cooking','Time:5.12.2019  Place: big Hall');

/*Table structure for table `college_student` */

DROP TABLE IF EXISTS `college_student`;

CREATE TABLE `college_student` (
  `name` varchar(50) DEFAULT NULL,
  `info` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `college_student` */

insert  into `college_student`(`name`,`info`) values ('Peter','Computer Science; The 3rd year; Student ID：51588'),('LiLy','Math; The 1st year; Student ID：651599'),('Tom','Biology; The last year; Student ID：105'),('Ben','Chemistry; The 2nd year; Student ID：26666');

/*Table structure for table `college_teacher` */

DROP TABLE IF EXISTS `college_teacher`;

CREATE TABLE `college_teacher` (
  `name` varchar(30) DEFAULT NULL,
  `information` varchar(2000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `college_teacher` */

insert  into `college_teacher`(`name`,`information`) values ('Ben','Professor Ben; Addr: 17th room, Big hall; Current position: 8th Room'),('Lily','Professor Lily; Addr: 18th room, Prince hall; Current position: 77th Room'),('Peter','Professor Peter; Addr: 200th room, Golden hall; Current position: 6th classoom'),('Tom','Professor Tom; Addr: 200th room, Golden hall; Current position: 6th classoom');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
