import pymysql
from tkinter import *

def position():
    # 打开数据库连接
    db = pymysql.connect("localhost", "root", "password", "college")

    # 使用cursor()方法获取操作游标
    cursor = db.cursor()

    # SQL 查询语句
    sql = "SELECT * FROM  college_position"
    results = ''
    try:
        # 执行SQL语句
        cursor.execute(sql)
        # 获取所有记录列表
        results = cursor.fetchall()
        print(results)
    except:
        print("Error: unable to fetch data")

    # 关闭数据库连接
    db.close()
    results = str(results).split("'")
    print(results[1])
    return results[1]

