import pymysql
from tkinter import *

loginstate = 0
# def news_func1(events):
#     global title, content
#     window = Tk()
#     window.title('News')
#     window.geometry('720x405')
#     window["background"] = "#22BB22"
#
#     label_news1 = Label(window, text="Title:" + title[0], width=720, height=0,
#                         bg='#556B2F', fg='#ffffff', font=('Arial', 10), anchor=W)
#     label_news2 = Text(window, width=100, height=10,
#                        bg='#556B2F', fg='#ffffff', font=('Arial', 10))
#     label_news2.insert(END, "Content:" + content[0])
#
#     label_news2.place(x=0, y=30)
#     label_news1.place(x=0, y=15, anchor=W)
#
#     window.mainloop()
#
#
# def news_func2(events):
#     global title, content
#     window = Tk()
#     window.title('News')
#     window.geometry('720x405')
#     window["background"] = "#22BB22"
#
#     label_news1 = Label(window, text="Title:" + title[1], width=720, height=0,
#                         bg='#556B2F', fg='#ffffff', font=('Arial', 10), anchor=W)
#     label_news2 = Text(window, width=100, height=10,
#                        bg='#556B2F', fg='#ffffff', font=('Arial', 10))
#     label_news2.insert(END, "Content:" + content[1])
#
#     label_news2.place(x=0, y=30)
#     label_news1.place(x=0, y=15, anchor=W)
#
#     window.mainloop()
#
#
# def news_func3(events):
#     global title, content
#     window = Tk()
#     window.title('News')
#     window.geometry('720x405')
#     window["background"] = "#22BB22"
#
#     label_news1 = Label(window, text="Title:" + title[2], width=720, height=0,
#                         bg='#556B2F', fg='#ffffff', font=('Arial', 10), anchor=W)
#     label_news2 = Text(window, width=100, height=10,
#                        bg='#556B2F', fg='#ffffff', font=('Arial', 10))
#     label_news2.insert(END, "Content:" + content[2])
#
#     label_news2.place(x=0, y=30)
#     label_news1.place(x=0, y=15, anchor=W)
#
#     window.mainloop()
#
#
# def news_func4(events):
#     global title, content
#     window = Tk()
#     window.title('News')
#     window.geometry('720x405')
#     window["background"] = "#22BB22"
#
#     label_news1 = Label(window, text="Title:" + title[3], width=720, height=0,
#                         bg='#556B2F', fg='#ffffff', font=('Arial', 10), anchor=W)
#     label_news2 = Text(window, width=100, height=10,
#                        bg='#556B2F', fg='#ffffff', font=('Arial', 10))
#     label_news2.insert(END, "Content:" + content[3])
#
#     label_news2.place(x=0, y=30)
#
#     label_news1.place(x=0, y=15, anchor=W)
#
#     window.mainloop()
#
#
# def news_func5(events):
#     global title, content
#     window = Tk()
#     window.title('News')
#     window.geometry('720x405')
#     window["background"] = "#22BB22"
#
#     label_news1 = Label(window, text="Title:" + title[4], width=720, height=0,
#                         bg='#556B2F', fg='#ffffff', font=('Arial', 10), anchor=W)
#     label_news2 = Text(window, width=100, height=10,
#                        bg='#556B2F', fg='#ffffff', font=('Arial', 10))
#     label_news2.insert(END, "Content:" + content[4])
#
#     label_news2.place(x=0, y=30)
#     label_news1.place(x=0, y=15, anchor=W)
#
#     window.mainloop()

login_state = 0

def func_confirm(event):
    print("Confirming")

def func_confirmRegister(event):
    print("Confirming")

def confirm(myid,mypass,label_loginshowInfo,win):
    global login_state
    id, password = mysql_login()
    for i in range(len(id)):
        print(str(i)+"----------")
        print(id[i])
        print(myid)
        print(password[i])
        print(mypass)
        if str(id[i]) == str(myid):
            print("same id")
        if  str(password[i]) == str(mypass):
            print("same password")
        if str(id[i]) == str(myid) and str(password[i]) == str(mypass):
            label_loginshowInfo.place(x=350, y=250, anchor=CENTER)
            label_loginshowInfo['bg'] = '#2E8B57'
            label_loginshowInfo['text'] = 'Login successfully!'
            login_state = 1
            print("Login successfully!")
            loginstate = 1
            break
        else:
            label_loginshowInfo.place(x=350, y=250, anchor=CENTER)
            label_loginshowInfo['bg'] = '#DC143C'
            label_loginshowInfo['text'] = 'Wrong ID or paaword'

def confirm_Register(myid,mypass,label_loginshowInfo,win):
    global login_state

    label_loginshowInfo.place(x=350, y=250, anchor=CENTER)
    label_loginshowInfo['bg'] = '#008000'
    label_loginshowInfo['text'] = 'Waiting for the confirmation from School !'

def redister(event):
    window = Tk()
    window.title('LOGIN')
    window.geometry('720x405')
    window["background"] = "#BC8F8F"
    # label_news1  = Label(window, text="1."+title[0], width=720, height=0,
    #                 bg='#22BB22', fg='#ffffff', font=('Arial', 10),anchor = W )
    # label_news2 = Label(window, text="2."+title[1], width=720, height=0,
    #                     bg='#22BB22', fg='#ffffff', font=('Arial', 10),anchor = W)
    # label_news3 = Label(window, text="3." + title[2], width=720, height=0,
    #                     bg='#22BB22', fg='#ffffff', font=('Arial', 10), anchor=W)
    # label_news4 = Label(window, text="4."+title[3], width=720, height=0,
    #                     bg='#22BB22', fg='#ffffff', font=('Arial', 10),anchor = W)
    # label_news5 = Label(window, text="5."+title[4], width=720, height=0,
    #                     bg='#22BB22', fg='#ffffff', font=('Arial', 10),anchor = W)
    #
    # label_news1.place(x=0,y=15,anchor = W)
    # label_news2.place(x=0, y=55, anchor=W)
    # label_news3.place(x=0, y=95, anchor=W)
    # label_news4.place(x=0, y=135, anchor=W)
    # label_news5.place(x=0, y=175, anchor=W)
    #
    # label_news1.bind("<Button-1>", news_func1)
    # label_news2.bind("<Button-1>", news_func2)
    # label_news3.bind("<Button-1>", news_func3)
    # label_news4.bind("<Button-1>", news_func4)
    # label_news5.bind("<Button-1>", news_func5)

    label_login_title = Label(window, text="Registion system", width=50, height=0,
                              bg='#C0C0C0', fg='#ffffff', font=('Arial', 10), anchor=CENTER)

    label_login_title.place(x=360, y=30, anchor=CENTER)

    text_login_id = Entry(window, width=30, bg='#C0C0C0', fg='#ffffff', font=('Arial', 10))

    text_login_pass = Entry(window, width=30, bg='#C0C0C0', fg='#ffffff', font=('Arial', 10))

    label_login_id = Label(window, text="ID   -------------------------------------------", width=20, height=0,
                           bg='#BC8F8F', fg='#ffffff', font=('Arial', 10), anchor=NW)

    label_login_pass = Label(window, text="pass   -----------------------------------------", width=20, height=0,
                             bg='#BC8F8F', fg='#ffffff', font=('Arial', 10), anchor=NW)

    button_newaccount = Button(window, text="Register", width=20, height=1,
                               bg='#BDB76B', fg='#ffffff', font=('Arial', 10), anchor=CENTER)

    label_loginshowInfo = Label(window, text="", width=60, height=0,
                                bg='#DC143C', fg='#ffffff', font=('Arial', 15), anchor=CENTER)

    button_confire = Button(window, text="Register", width=20, height=1,
                            bg='#BDB76B', fg='#ffffff', font=('Arial', 10), anchor=CENTER,
                            command=lambda: confirm_Register(text_login_id.get(), text_login_pass.get(), label_loginshowInfo,
                                                    window))

    text_login_id.place(x=350, y=70, anchor=NW)
    text_login_pass.place(x=350, y=100, anchor=NW)

    label_login_id.place(x=150, y=70, anchor=NW)
    label_login_pass.place(x=150, y=100, anchor=NW)

    button_confire.place(x=150, y=150, anchor=NW)


    text_login_pass['show'] = '*'

    button_confire.bind("<Button-1>", func_confirmRegister)

def mysql_login():
    # 打开数据库连接
    db = pymysql.connect("localhost", "root", "password", "college")

    # 使用cursor()方法获取操作游标
    cursor = db.cursor()
    id = []
    password = []
    # SQL 查询语句
    sql = "SELECT * FROM  college_login"
    try:
        # 执行SQL语句
        cursor.execute(sql)
        # 获取所有记录列表
        results = cursor.fetchall()
        for row in results:
            id.append(row[0])
            password.append(row[1])
    except:
        print("Error: unable to fetch data")
    # 关闭数据库连接
    db.close()
    return id,password



def showlogin():


    window = Tk()
    window.title('LOGIN')
    window.geometry('720x405')
    window["background"] = "#BC8F8F"
    # label_news1  = Label(window, text="1."+title[0], width=720, height=0,
    #                 bg='#22BB22', fg='#ffffff', font=('Arial', 10),anchor = W )
    # label_news2 = Label(window, text="2."+title[1], width=720, height=0,
    #                     bg='#22BB22', fg='#ffffff', font=('Arial', 10),anchor = W)
    # label_news3 = Label(window, text="3." + title[2], width=720, height=0,
    #                     bg='#22BB22', fg='#ffffff', font=('Arial', 10), anchor=W)
    # label_news4 = Label(window, text="4."+title[3], width=720, height=0,
    #                     bg='#22BB22', fg='#ffffff', font=('Arial', 10),anchor = W)
    # label_news5 = Label(window, text="5."+title[4], width=720, height=0,
    #                     bg='#22BB22', fg='#ffffff', font=('Arial', 10),anchor = W)
    #
    # label_news1.place(x=0,y=15,anchor = W)
    # label_news2.place(x=0, y=55, anchor=W)
    # label_news3.place(x=0, y=95, anchor=W)
    # label_news4.place(x=0, y=135, anchor=W)
    # label_news5.place(x=0, y=175, anchor=W)
    #
    # label_news1.bind("<Button-1>", news_func1)
    # label_news2.bind("<Button-1>", news_func2)
    # label_news3.bind("<Button-1>", news_func3)
    # label_news4.bind("<Button-1>", news_func4)
    # label_news5.bind("<Button-1>", news_func5)

    label_login_title = Label(window, text="Login system", width=50, height=0,
                         bg='#C0C0C0', fg='#ffffff', font=('Arial', 10),anchor = CENTER)

    label_login_title.place(x=360,y= 30,anchor = CENTER)

    text_login_id = Entry(window, width=30, bg='#C0C0C0', fg='#ffffff', font=('Arial', 10))

    text_login_pass = Entry(window, width=30, bg='#C0C0C0', fg='#ffffff', font=('Arial', 10))

    label_login_id= Label(window, text="ID   -------------------------------------------", width=20, height=0,
                         bg='#BC8F8F', fg='#ffffff', font=('Arial', 10),anchor = NW)

    label_login_pass = Label(window, text="pass   -----------------------------------------", width=20, height=0,
                              bg='#BC8F8F', fg='#ffffff', font=('Arial', 10), anchor=NW)


    button_newaccount = Button(window, text="Register", width=20, height=1,
                            bg='#BDB76B', fg='#ffffff', font=('Arial', 10), anchor=CENTER)

    label_loginshowInfo= Label(window, text="Wrong ID or password!!!", width=20, height=0,
                             bg='#DC143C', fg='#ffffff', font=('Arial', 15), anchor=CENTER)

    button_confire = Button(window, text="Login", width=20, height=1,
                              bg='#BDB76B', fg='#ffffff', font=('Arial', 10), anchor=CENTER,
                            command=lambda :confirm(text_login_id.get(),text_login_pass.get(),label_loginshowInfo,window))

    text_login_id.place(x=350, y=70, anchor=NW)
    text_login_pass.place(x=350, y=100, anchor=NW)

    label_login_id.place(x=150, y=70, anchor=NW)
    label_login_pass.place(x=150, y=100, anchor=NW)

    button_confire.place(x=150, y=150, anchor=NW)
    button_newaccount.place(x=350, y=150, anchor=NW)



    text_login_pass['show'] = '*'

    button_confire.bind("<Button-1>", func_confirm)
    button_newaccount.bind("<Button-1>",redister)

    window.mainloop()

