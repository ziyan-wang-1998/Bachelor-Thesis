from voiceTOtext import my_voice_
from my_voice_ import texttovoice
from tkinter import *
import time
import _thread
import os
import mysql_history
import mysql_news
import mysql_position
import mysql_society
import mysql_login
import mysql_teachers
import re
import mysql_book
import mysql_canteen
import mysql_student

count = 0


def tipsTologin():
    window = Tk()
    window.title('News')
    window.geometry('300x50')
    window["background"] = "#696969"
    label_news1 = Label(window, text="Please login to view this part!", width=720, height=0,
                        bg='#22BB22', fg='#ffffff', font=('Arial', 10))
    label_news1.pack()
    window.mainloop()

def showtime():
    while 1:
        global lable_time
        lable_time["text"] = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time()))

def analysis_name(mystr):
    Information = ''
    array_name = mystr.split(" ")
    real_name = ""
    for i in range(len(array_name)):
        array_name[i] = ''.join(e for e in array_name[i] if e.isalnum())
        print("Kry word:"+array_name[i])
        ########################################################################################################################
        if array_name[i] == "professor" or array_name[i] == "Professor":
            real_name = "Are you finding the professor "+array_name[i+1]+" Look at the the bottom!"
            name = ''.join(e for e in array_name[i+1] if e.isalnum())
            Information = mysql_teachers.mysql_news(name)
        ########################################################################################################################
        if array_name[i] == "student" or array_name[i] == "Student":
            real_name = "Are you finding the student " + array_name[i + 1] + " Look at the the bottom!"
            name = ''.join(e for e in array_name[i + 1] if e.isalnum())
            Information = mysql_student.mysql_news(name)
        ########################################################################################################################
        if array_name[i] == "book" or array_name[i] == "Book":
            real_name = "Are you finding the book"
            name = ''
            for j  in range(i+1,len(array_name)):
                real_name += " "+array_name[j]
                name += array_name[j]
                name = ''.join(e for e in name if e.isalnum())
            Information = mysql_book.mysql_news(name)
            real_name += " Look at the the bottom!"

        ########################################################################################################################
        if array_name[i] == 'canteen' or array_name[i] == 'Canteen':
            _thread.start_new_thread(mysql_canteen.shownews, ())
        ########################################################################################################################
        if array_name[i] == 'news' or array_name[i] == 'News':
            _thread.start_new_thread(mysql_news.shownews, ())
        ########################################################################################################################
        if array_name[i] == 'club' or array_name[i] == 'Club' or array_name[i] == 'Clubs' or array_name[i] == 'Clubs':
            _thread.start_new_thread(mysql_society.shownews, ())

        ########################################################################################################################
        if array_name[i] == 'history' or array_name[i] == 'History':
            _thread.start_new_thread(mysql_history.showhistory, ())
        ########################################################################################################################
        if array_name[i] == 'position' or array_name[i] == 'Position':
            func2_postion(None)

########################################################################################################################
    if real_name == "":
        real_name = "No results! Try again, please!"
    return real_name,Information

def get_voice():
    global _str_
    global lable_showinfo
    global _str_
    global lable_detailsInfo
    global lable_detailsAnalysis
    global lable_showinfo_teacherORbook
    global sound_flag
    global choose_sound
    lable_showinfo_teacherORbook.delete('1.0','end')
    lable_detailsInfo["text"] = ""
    lable_detailsAnalysis["text"] = ""
    _str_ = my_voice_()
    lable_showinfo["text"] = "Saying over"
    lable_detailsInfo["text"] = _str_
    showtext,Information = analysis_name(_str_)
    lable_detailsAnalysis["text"] = showtext
    if showtext != "No results! Try again, please!":

        lable_showinfo_teacherORbook.place(x=640, y=550, anchor=CENTER)
        lable_showinfo_teacherORbook.delete('1.0', 'end')
        lable_showinfo_teacherORbook.insert(END, Information)
        choose_sound += 1
        texttovoice(Information, choose_sound)




def func1_startvoice(event):
    global lable_showinfo
    global _str_
    global lable_detailsInfo
    global lable_detailsAnalysis
    global lable_showinfo_teacherORbook
    global sound_flag
    global choose_sound
    # voice recog
    lable_showinfo["text"] = "Saying"
    _thread.start_new_thread(get_voice, ())

def func2_postion(event):
    global lable_showinfo
    global _str_
    global lable_detailsInfo
    global lable_detailsAnalysis
    global lable_showinfo_teacherORbook
    global sound_flag
    global choose_sound
    lable_showinfo["text"] = ""
    lable_detailsInfo["text"] = "You are here!"
    lable_detailsAnalysis["text"] = ""
    lable_showinfo_teacherORbook.place(x=640, y=550, anchor=CENTER)
    lable_showinfo_teacherORbook.delete('1.0', 'end')
    postion_str = mysql_position.position()
    lable_showinfo_teacherORbook.insert(END, postion_str)
    if sound_flag > 0:
        choose_sound += 1
        texttovoice(postion_str,choose_sound)

def func3_playsound(event):
    global sound_flag
    sound_flag = -sound_flag
    if sound_flag > 0:
        button_photo3 = PhotoImage(file="pic/sound2.gif")
        button_sound.config(image=button_photo3)
        button_sound.image = button_photo3
    else:
        button_photo3 = PhotoImage(file="pic/sound1.gif")
        button_sound.config(image=button_photo3)
        button_sound.image = button_photo3

def func3_history(event):
    _thread.start_new_thread(mysql_history.showhistory, ())

def func4_news(event):
    _thread.start_new_thread(mysql_news.shownews, ())

def func5_society(event):
    if mysql_login.login_state == 1:
        _thread.start_new_thread(mysql_society.shownews, ())
    else:
        _thread.start_new_thread(tipsTologin, ())

def func2_login(event):
    _thread.start_new_thread(mysql_login.showlogin, ())

def func5_canteen(event):
    _thread.start_new_thread(mysql_canteen.shownews, ())



_str_ = ''
sound_flag = -1
choose_sound = 0





window = Tk()
window.title('Book and Teacher Query System ')
window.geometry('1280x720')  # 窗口大小为300x200
window["background"] = "#696969"

button_photo1 = PhotoImage(file="pic/maike2.gif")
button_photo2 = PhotoImage(file="pic/position.gif")
button_photo3 = PhotoImage(file="pic/sound1.gif")
button_photo4 = PhotoImage(file="pic/history.gif")
button_photo5 = PhotoImage(file="pic/news.gif")
button_photo6 = PhotoImage(file="pic/society.gif")
button_photo7 = PhotoImage(file="pic/login.gif")
button_photo8 = PhotoImage(file="pic/canteen.gif")

lable_title = Label(window, text="Book and Teacher Query System @Machine id:005", width=50, height=10,
                    bg='DimGray', fg='#ffffff', font=('Arial', 25))
lable_showinfo = Label(window,
                       text="Please click button to say something: where is the book xxx or where is the pofessor xxx",
                       width=80, height=5, bg='DimGray', fg='#ffffff', font=('Arial', 12))
lable_detailsInfo = Label(window, text="", width=80, height=5, bg='DimGray', fg='#ffffff', font=('Arial', 20))
lable_detailsAnalysis = Label(window, text="", width=80, height=5, bg='DimGray', fg='#ffffff', font=('Arial', 20))
lable_showinfo_teacherORbook = Text(window, width=50, height=5, bg='#808080', fg='#ffffff', font=('Arial', 20))
lable_time = Label(window, width=14, height=0, bg='#696969', fg='#ffffff', font=('Arial', 10))
lable_login_showstate = Label(window,text="Not login yet...", width=0, height=0, bg='#696969', fg='#ffffff', font=('Arial', 12))


button_startVoice = Label(window, width=100, height=130, bg='#DEB887', fg='#ffffff', font=('Arial', 12),
                          image=button_photo1)
button_sound = Label(window, width=100, height=100, bg='#DEB887', fg='#ffffff', font=('Arial', 12),
                     image=button_photo3)
button_canteen = Label(window, width=100, height=100, bg='#DEB887', fg='#ffffff', font=('Arial', 12),
                     image=button_photo8)


button_position = Label(window, width=100, height=100, bg='#DEB887', fg='#ffffff', font=('Arial', 12),
                        image=button_photo2)
button_history = Label(window, width=100, height=100, bg='#DEB887', fg='#ffffff', font=('Arial', 12),
                       image=button_photo4)
button_news = Label(window, width=100, height=100, bg='#DEB887', fg='#ffffff', font=('Arial', 12),
                       image=button_photo5)
button_society = Label(window, width=100, height=100, bg='#DEB887', fg='#ffffff', font=('Arial', 12),
                       image=button_photo6)
button_login = Label(window, width=110, height=28, bg='#DEB887', fg='#ffffff', font=('Arial', 12),
                       image=button_photo7)

lable_time.place(x=0, y=0, anchor=NW)
lable_title.place(x=640, y=50, anchor=CENTER)
lable_showinfo.place(x=640, y=200, anchor=CENTER)
lable_detailsInfo.place(x=640, y=300, anchor=CENTER)
lable_detailsAnalysis.place(x=640, y=400, anchor=CENTER)
#lable_login_showstate.place(x=1150, y=45, anchor=NW)

button_startVoice.place(x=100, y=200, anchor=CENTER)
button_sound.place(x=100, y=350, anchor=CENTER)
button_canteen.place(x=100, y=500, anchor=CENTER)

button_login.place(x=1200, y=20, anchor=CENTER)
button_position.place(x=1200, y=150, anchor=CENTER)
button_history.place(x=1200, y=300, anchor=CENTER)
button_news.place(x=1200, y=450, anchor=CENTER)
button_society.place(x=1200, y=600, anchor=CENTER)


button_login.bind("<Button-1>", func2_login)
button_position.bind("<Button-1>", func2_postion)
button_startVoice.bind("<Button-1>", func1_startvoice)
button_sound.bind("<Button-1>", func3_playsound)
button_history.bind("<Button-1>", func3_history)
button_news.bind("<Button-1>", func4_news)
button_society.bind("<Button-1>", func5_society)
button_canteen.bind("<Button-1>", func5_canteen)


_thread.start_new_thread(showtime, ())

window.mainloop()


