import pymysql

def mysql_news(name):
    # 打开数据库连接
    print("Received name:"+ name)
    db = pymysql.connect("localhost", "root", "password", "college")

    # 使用cursor()方法获取操作游标
    cursor = db.cursor()
    title = []
    content = []
    # SQL 查询语句
    sql = "SELECT * FROM  college_book"
    try:
        # 执行SQL语句
        cursor.execute(sql)
        # 获取所有记录列表
        results = cursor.fetchall()
        for row in results:
            title.append(row[0])
            content.append(row[1])
    except:
        print("Error: unable to fetch data")
    # 关闭数据库连接
    db.close()
    for i in range(len(title)):
        print(title[i])
        if title[i] == name:
            return content[i]
    return "No Information"

