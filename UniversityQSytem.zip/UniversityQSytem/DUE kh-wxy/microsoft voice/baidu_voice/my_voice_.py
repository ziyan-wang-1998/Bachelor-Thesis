from playsound import *
from aip import AipSpeech
import os

def texttovoice(_str,flag):
    APP_ID = '16008139'
    API_KEY = '7axGD9GPQ2XDFBfMxPKRrkhj'
    SECRET_KEY = 'h7dNGjatyIbiyOak5od1BQCTYWqyW8nB'

    client = AipSpeech(APP_ID, API_KEY, SECRET_KEY)

    result = client.synthesis(_str, 'zh', 1, {
        'vol': 5,
    })

    # 识别正确返回语音二进制 错误则返回dict 参照下面错误码
    mystr = str("sound/"+"auido"+str(flag)+".mp3")
    print(mystr)
    file1 = mystr

    try:
        os.remove(file1)
    except Exception:
        pass
    if not isinstance(result, dict):
        with open(file1, 'wb+') as f:
            f.write(result)
            f.close()
    playsound(file1)

