import pymysql
from tkinter import *

def news_func1(events):
    global title, content
    window = Tk()
    window.title('News')
    window.geometry('720x405')
    window["background"] = "#22BB22"

    label_news1 = Label(window, text="Title:" + title[0], width=720, height=0,
                        bg='#556B2F', fg='#ffffff', font=('Arial', 10), anchor=W)
    label_news2 = Text(window, width=100, height=10,
                       bg='#556B2F', fg='#ffffff', font=('Arial', 10))
    label_news2.insert(END, "Content:" + content[0])

    label_news2.place(x=0, y=30)
    label_news1.place(x=0, y=15, anchor=W)

    window.mainloop()


def news_func2(events):
    global title, content
    window = Tk()
    window.title('News')
    window.geometry('720x405')
    window["background"] = "#22BB22"

    label_news1 = Label(window, text="Title:" + title[1], width=720, height=0,
                        bg='#556B2F', fg='#ffffff', font=('Arial', 10), anchor=W)
    label_news2 = Text(window, width=100, height=10,
                       bg='#556B2F', fg='#ffffff', font=('Arial', 10))
    label_news2.insert(END, "Content:" + content[1])

    label_news2.place(x=0, y=30)
    label_news1.place(x=0, y=15, anchor=W)

    window.mainloop()


def news_func3(events):
    global title, content
    window = Tk()
    window.title('News')
    window.geometry('720x405')
    window["background"] = "#22BB22"

    label_news1 = Label(window, text="Title:" + title[2], width=720, height=0,
                        bg='#556B2F', fg='#ffffff', font=('Arial', 10), anchor=W)
    label_news2 = Text(window, width=100, height=10,
                       bg='#556B2F', fg='#ffffff', font=('Arial', 10))
    label_news2.insert(END, "Content:" + content[2])

    label_news2.place(x=0, y=30)
    label_news1.place(x=0, y=15, anchor=W)

    window.mainloop()


def news_func4(events):
    global title, content
    window = Tk()
    window.title('News')
    window.geometry('720x405')
    window["background"] = "#22BB22"

    label_news1 = Label(window, text="Title:" + title[3], width=720, height=0,
                        bg='#556B2F', fg='#ffffff', font=('Arial', 10), anchor=W)
    label_news2 = Text(window, width=100, height=10,
                       bg='#556B2F', fg='#ffffff', font=('Arial', 10))
    label_news2.insert(END, "Content:" + content[3])

    label_news2.place(x=0, y=30)

    label_news1.place(x=0, y=15, anchor=W)

    window.mainloop()


def news_func5(events):
    global title, content
    window = Tk()
    window.title('News')
    window.geometry('720x405')
    window["background"] = "#22BB22"

    label_news1 = Label(window, text="Title:" + title[4], width=720, height=0,
                        bg='#556B2F', fg='#ffffff', font=('Arial', 10), anchor=W)
    label_news2 = Text(window, width=100, height=10,
                       bg='#556B2F', fg='#ffffff', font=('Arial', 10))
    label_news2.insert(END, "Content:" + content[4])

    label_news2.place(x=0, y=30)
    label_news1.place(x=0, y=15, anchor=W)

    window.mainloop()

def mysql_news():
    # 打开数据库连接
    db = pymysql.connect("localhost", "root", "password", "college")

    # 使用cursor()方法获取操作游标
    cursor = db.cursor()
    title = []
    content = []
    # SQL 查询语句
    sql = "SELECT * FROM  college_news"
    try:
        # 执行SQL语句
        cursor.execute(sql)
        # 获取所有记录列表
        results = cursor.fetchall()
        for row in results:
            title.append(row[0])
            content.append(row[1])
    except:
        print("Error: unable to fetch data")
    # 关闭数据库连接
    db.close()
    return title,content

title,content  = mysql_news()

def shownews():
    global title,content
    title,content = mysql_news()
    window = Tk()
    window.title('News')
    window.geometry('720x405')
    window["background"] = "#696969"

    label_news1  = Label(window, text="1."+title[0], width=720, height=0,
                    bg='#22BB22', fg='#ffffff', font=('Arial', 10),anchor = W )
    label_news2 = Label(window, text="2."+title[1], width=720, height=0,
                        bg='#22BB22', fg='#ffffff', font=('Arial', 10),anchor = W)
    label_news3 = Label(window, text="3." + title[2], width=720, height=0,
                        bg='#22BB22', fg='#ffffff', font=('Arial', 10), anchor=W)
    label_news4 = Label(window, text="4."+title[3], width=720, height=0,
                        bg='#22BB22', fg='#ffffff', font=('Arial', 10),anchor = W)
    label_news5 = Label(window, text="5."+title[4], width=720, height=0,
                        bg='#22BB22', fg='#ffffff', font=('Arial', 10),anchor = W)

    label_news1.place(x=0,y=15,anchor = W)
    label_news2.place(x=0, y=55, anchor=W)
    label_news3.place(x=0, y=95, anchor=W)
    label_news4.place(x=0, y=135, anchor=W)
    label_news5.place(x=0, y=175, anchor=W)

    label_news1.bind("<Button-1>", news_func1)
    label_news2.bind("<Button-1>", news_func2)
    label_news3.bind("<Button-1>", news_func3)
    label_news4.bind("<Button-1>", news_func4)
    label_news5.bind("<Button-1>", news_func5)

    window.mainloop()
