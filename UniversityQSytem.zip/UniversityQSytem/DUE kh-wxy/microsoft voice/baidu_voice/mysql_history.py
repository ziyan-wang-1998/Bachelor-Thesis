import pymysql
from tkinter import *

def mysql_history():
    # 打开数据库连接
    db = pymysql.connect("localhost", "root", "password", "college")

    # 使用cursor()方法获取操作游标
    cursor = db.cursor()
    results = ''
    # SQL 查询语句
    sql = "SELECT * FROM  college_history"
    try:
        # 执行SQL语句
        cursor.execute(sql)
        # 获取所有记录列表
        results = cursor.fetchall()
        print(results)
    except:
        print("Error: unable to fetch data")
    results = str(results).split("'")
    print(results[1])
    # 关闭数据库连接
    db.close()
    return results[1]

def showhistory():
    window = Tk()
    window.title('History of School')
    window.geometry('400x400')
    window.geometry("+600+50")
    window["background"] = "#696969"

    lable_showinfo_teacherORbook = Text(window, width=130, height=130, bg='#808080', fg='#ffffff', font=('Arial', 10))

    lable_showinfo_teacherORbook.pack(anchor=CENTER)

    lable_showinfo_teacherORbook.insert(END,mysql_history())

    window.mainloop()